package employee.management.system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;

public class Conn 
{
	Statement s ;
	public Conn()
	{
		Connection c;
		//Statement s ;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			c = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee_management_system","root","@#HkAk9012");
			s = c.createStatement();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
	}

}
