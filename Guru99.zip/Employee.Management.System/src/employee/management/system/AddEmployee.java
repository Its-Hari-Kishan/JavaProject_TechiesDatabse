package employee.management.system;

import java.awt.*;
import javax.swing.*;
import com.toedter.calendar.JDateChooser;
import java.util.*;
import java.awt.event.*;

public class AddEmployee extends JFrame implements ActionListener
{
	
	Random ran = new Random();
	int number = ran.nextInt(999999);
	
	JTextField tfname, tffname, tfaddress, tfphone, tfemail, tfsalary, tfaadhar,tfdesignation;
	JDateChooser dcdob;
	JComboBox<String> cbeducation, cbdesignation;
	JLabel lblempid;
	JButton add, back;
	
	AddEmployee()
	{	
		getContentPane().setBackground(Color.WHITE);
		setLayout(null);
		
		JLabel heading = new JLabel("Add Employee Detail");
		heading.setBounds(330, 30, 500, 50);
		heading.setFont(new Font("algerian",Font.BOLD, 35));
		add(heading);
		
		JLabel labelname = new JLabel("Name");
		labelname.setBounds(50, 150, 150, 30);
		labelname.setFont(new Font("serif",Font.BOLD,25));
		add(labelname);
		
		tfname = new JTextField();
		tfname.setBounds(200, 150, 150, 30);
		add(tfname);
		
		JLabel labelfname = new JLabel("Father's Name");
		labelfname.setBounds(400, 150, 200, 30);
		labelfname.setFont(new Font("serif",Font.BOLD,25));
		add(labelfname);
		
		tffname = new JTextField();
		tffname.setBounds(600, 150, 150, 30);
		add(tffname);
		
		JLabel labeldob = new JLabel("Date of Birth");
		labeldob.setBounds(50, 200, 200, 30);
		labeldob.setFont(new Font("serif",Font.BOLD,25));
		add(labeldob);
		
		dcdob = new JDateChooser();
		dcdob.setBounds(200, 200, 150, 30);
		add(dcdob);
		
		JLabel labelsalary = new JLabel("Salary Amount");
		labelsalary.setBounds(400, 200, 200, 30);
		labelsalary.setFont(new Font("serif",Font.BOLD,25));
		add(labelsalary);
		
		tfsalary = new JTextField();
		tfsalary.setBounds(600, 200, 150, 30);
		add(tfsalary);
		
		JLabel labeladdress = new JLabel("Address");
		labeladdress.setBounds(50, 250, 200, 30);
		labeladdress.setFont(new Font("serif",Font.BOLD,25));
		add(labeladdress);
		
		tfaddress = new JTextField();
		tfaddress.setBounds(200, 250, 150, 30);
		add(tfaddress);
		
		JLabel labelphone = new JLabel("Phone Number");
		labelphone.setBounds(400, 250, 200, 30);
		labelphone.setFont(new Font("serif",Font.BOLD,25));
		add(labelphone);
		
		tfphone = new JTextField();
		tfphone.setBounds(600, 250, 150, 30);
		add(tfphone);
		
		JLabel labelemail = new JLabel("E-mail");
		labelemail.setBounds(50, 300, 200, 30);
		labelemail.setFont(new Font("serif",Font.BOLD,25));
		add(labelemail);
		
		tfemail = new JTextField();
		tfemail.setBounds(200, 300, 150, 30);
		add(tfemail);
		
		JLabel labeleducation = new JLabel("Higher Education");
		labeleducation.setBounds(400, 300, 200, 30);
		labeleducation.setFont(new Font("serif",Font.BOLD,25));
		add(labeleducation);
		
		String courses[] = {"BBA","BCA","B.Tech","BA","BSC","B.COM","MBA","MCA","M.Tech","MA","MSC","M.COM","PHD"};
		cbeducation = new JComboBox<String>(courses);
		cbeducation.setBackground(Color.WHITE);
		cbeducation.setBounds(600, 300, 150, 30);
		add(cbeducation);
		
		JLabel labeldesignation = new JLabel("Designation");
		labeldesignation.setBounds(50, 350, 200, 30);
		labeldesignation.setFont(new Font("serif",Font.BOLD,25));
		add(labeldesignation);
		
		String designation[] = {"Software Engineer","Software Developer", "Software Tester","Web Developer","System Administrator","Database Administrator","Human Resource Manager","Project Manager","Business Analyst","IT Suppport"};
		cbdesignation = new JComboBox<String>(designation);
		cbdesignation.setBackground(Color.WHITE);
		cbdesignation.setBounds(200,350,150,30);
		add(cbdesignation);
		
		
		JLabel labelaadhar = new JLabel("Aadhar Number");
		labelaadhar.setBounds(400, 350, 200, 30);
		labelaadhar.setFont(new Font("serif",Font.BOLD,25));
		add(labelaadhar);
		
		
		tfaadhar = new JTextField();
		tfaadhar.setBounds(600, 350, 150, 30);
		add(tfaadhar);
		
		JLabel labelempid = new JLabel("Employee Id- ");
		labelempid.setBounds(50, 400, 150, 30);
		labelempid.setFont(new Font("serif",Font.BOLD,25));
		add(labelempid);
		
		lblempid = new JLabel("" + number);
		lblempid.setBounds(200, 400, 150, 30);
		lblempid.setFont(new Font("serif",Font.BOLD,25));
		add(lblempid);
		
		add = new JButton("Add Data");
		add.setBounds(250, 550, 150, 40);
		add.setFont(new Font("serif",Font.BOLD,25));
		add.addActionListener(this);
		add.setBackground(Color.BLACK);
		add.setForeground(Color.WHITE);
		add(add);
		
		back = new JButton("Back");
		back.setBounds(450, 550, 150, 40);
		back.setFont(new Font("serif",Font.BOLD,25));
		back.setBackground(Color.BLACK);
		back.setForeground(Color.WHITE);
		back.addActionListener(this);
		add(back);
		
			
		
		setSize(1100,800);
		setLocation(400,100);
		setVisible(true);
		

	}
	
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource() == add)
		{
			if(validate_add())
			{
				String name = tfname.getText();
				String fname = tffname.getText();
				String dob = ((JTextField)dcdob.getDateEditor().getUiComponent()).getText();
				String salary = tfsalary.getText();
				String address = tfaddress.getText();
				String phone = tfphone.getText();
				String email = tfemail.getText();
				String education = (String) cbeducation.getSelectedItem();
				String designation = (String) cbdesignation.getSelectedItem();
				String aadhar = tfaadhar.getText();
				String empid = lblempid.getText();
				
				try
				{
					Conn conn = new Conn();
					String query = "INSERT INTO employee VALUES ('"+name+"','"+fname+"','"+dob+"','"+salary+"','"+address+"','"+phone+"','"+email+"','"+education+"','"+designation+"','"+aadhar+"','"+empid+"')";
					conn.s.executeUpdate(query);
					JOptionPane.showMessageDialog(null, "Details added Successfully");
					setVisible(false);
					new Home();
				}
				
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}	
		}
		else 
		{
			setVisible(false);
			new Home();
		}
	}
	
	
    public boolean validate_add() {
        boolean isValid = true;

        // Validate Name
        String name = tfname.getText();
        if (name.isEmpty() || !name.matches("^[a-zA-Z. ]{4,50}$")) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Invalid Name. It should contain alphabets only (4-50 characters).");
            return isValid;
        }

        // Validate Father's Name
        String fname = tffname.getText();
        if (fname.isEmpty() || !fname.matches("^[a-zA-Z. ]{4,50}$")) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Invalid Father's Name. It should contain alphabets and point(.) only (4-50 characters).");
            return isValid;
        }

        // Validate Date of Birth - You may add specific criteria if needed
        Date dob = dcdob.getDate();
        if (dob == null) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Please Choose a valid Date of Birth from the Calendar.");
            return isValid;
        }

        // Check if the chosen date is a future date
        if (dob.after(new Date())) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Future date of birth is not allowed.");
            return isValid;
        }

        // Check if the chosen date is the current date
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        int currentYear = cal.get(Calendar.YEAR);
        cal.setTime(dob);
        int chosenYear = cal.get(Calendar.YEAR);

        if (currentYear == chosenYear) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Current Year is not allowed.");
            return isValid;
        }

        // Check if the age is less than 18 years
        cal.setTime(new Date());
        cal.add(Calendar.YEAR, -18); // Subtract 18 years from the current date

        if (cal.getTime().before(dob)) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Age should be at least 18 years from the current date.");
            return isValid;
        }


        // Validate Salary Amount
        String salary = tfsalary.getText();
        if (salary.isEmpty() || !salary.matches("^[1-9]\\d{3,8}$")) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Invalid Salary Amount. It should contain numbers only (3-8 digits), 0 is not allowed at begining.");
            return isValid;
        }

        // Validate Address
        String address = tfaddress.getText();
        if (address.isEmpty() || !address.matches("^[a-zA-Z. ]{4,50}$")) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Invalid Address. It should contain alphabets only (4-50 characters).");
            return isValid;
        }

        // Validate Phone Number
        String phone = tfphone.getText();
        if (phone.isEmpty() || !phone.matches("^[6-9]\\d{9}$")) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Invalid Phone Number. It should contain exactly 10 numbers. and should not start with any (0-5 numbers).");
            return isValid;
        }

        // Validate Email
        String email = tfemail.getText();
        if (email.isEmpty() || !email.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Invalid Email. It should be a valid email address.");
            return isValid;
        }


        // Validate Aadhar Number
        String aadhar = tfaadhar.getText();
        if (aadhar.isEmpty() || !aadhar.matches("^[1-9]\\d{11}$")) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Invalid Aadhar Number. It should contain exactly 12 numbers. It should not start with O.");
            return isValid;
        }

        return isValid;
    }
	
    
	public static void main(String[] args)
	{
		new AddEmployee();

	}

}
