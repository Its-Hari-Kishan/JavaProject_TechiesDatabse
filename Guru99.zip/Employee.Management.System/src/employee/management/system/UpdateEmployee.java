package employee.management.system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Calendar;
import java.util.Date;

public class UpdateEmployee extends JFrame implements ActionListener
{
	
	JTextField tfeducation, tffname, tfaddress, tfphone, tfemail, tfsalary, tfaadhar, tfdesignation;
	JLabel lblempid;
	JComboBox<String> cbeducation, cbdesignation;
	JButton add, back;
	String empId;
	
	UpdateEmployee(String empId)
	{	
		this.empId = empId;
		getContentPane().setBackground(Color.WHITE);
		setLayout(null);
		
		JLabel heading = new JLabel("Update Employee Detail");
		heading.setBounds(330, 30, 500, 50);
		heading.setFont(new Font("algerian",Font.BOLD, 35));
		add(heading);
		
		JLabel labelname = new JLabel("Name");
		labelname.setBounds(50, 150, 150, 30);
		labelname.setFont(new Font("serif",Font.BOLD,25));
		add(labelname);
		
		JLabel lblname = new JLabel();
		lblname.setBounds(200, 150, 150, 30);
		add(lblname);
		
		JLabel labelfname = new JLabel("Father's Name");
		labelfname.setBounds(400, 150, 200, 30);
		labelfname.setFont(new Font("serif",Font.BOLD,25));
		add(labelfname);
		
		tffname = new JTextField();
		tffname.setBounds(600, 150, 150, 30);
		add(tffname);
		
		JLabel labeldob = new JLabel("Date of Birth");
		labeldob.setBounds(50, 200, 200, 30);
		labeldob.setFont(new Font("serif",Font.BOLD,25));
		add(labeldob);
		
		JLabel lbldob = new JLabel();
		lbldob.setBounds(200, 200, 150, 30);
		add(lbldob);
		
		JLabel labelsalary = new JLabel("Salary Amount");
		labelsalary.setBounds(400, 200, 200, 30);
		labelsalary.setFont(new Font("serif",Font.BOLD,25));
		add(labelsalary);
		
		tfsalary = new JTextField();
		tfsalary.setBounds(600, 200, 150, 30);
		add(tfsalary);
		
		JLabel labeladdress = new JLabel("Address");
		labeladdress.setBounds(50, 250, 200, 30);
		labeladdress.setFont(new Font("serif",Font.BOLD,25));
		add(labeladdress);
		
		tfaddress = new JTextField();
		tfaddress.setBounds(200, 250, 150, 30);
		add(tfaddress);
		
		JLabel labelphone = new JLabel("Phone Number");
		labelphone.setBounds(400, 250, 200, 30);
		labelphone.setFont(new Font("serif",Font.BOLD,25));
		add(labelphone);
		
		tfphone = new JTextField();
		tfphone.setBounds(600, 250, 150, 30);
		add(tfphone);
		
		JLabel labelemail = new JLabel("E-mail");
		labelemail.setBounds(50, 300, 200, 30);
		labelemail.setFont(new Font("serif",Font.BOLD,25));
		add(labelemail);
		
		tfemail = new JTextField();
		tfemail.setBounds(200, 300, 150, 30);
		add(tfemail);
		
		JLabel labeleducation = new JLabel("Higher Education");
		labeleducation.setBounds(400, 300, 200, 30);
		labeleducation.setFont(new Font("serif",Font.BOLD,25));
		add(labeleducation);
		
		String courses[] = {"BBA","BCA","B.Tech","BA","BSC","B.COM","MBA","MCA","M.Tech","MA","MSC","M.COM","PHD"};
		cbeducation = new JComboBox<String>(courses);
		cbeducation.setBackground(Color.WHITE);
		cbeducation.setBounds(600, 300, 150, 30);
		add(cbeducation);
		
		JLabel labeldesignation = new JLabel("Designation");
		labeldesignation.setBounds(50, 350, 200, 30);
		labeldesignation.setFont(new Font("serif",Font.BOLD,25));
		add(labeldesignation);
		
		String designation[] = {"Software Engineer","Software Developer", "Software Tester","Web Developer","System Administrator","Database Administrator","Human Resource Manager","Project Manager","Business Analyst","IT Suppport"};
		cbdesignation = new JComboBox<String>(designation);
		cbdesignation.setBackground(Color.WHITE);
		cbdesignation.setBounds(200,350,150,30);
		add(cbdesignation);
		
		JLabel labelaadhar = new JLabel("Aadhar Number");
		labelaadhar.setBounds(400, 350, 200, 30);
		labelaadhar.setFont(new Font("serif",Font.BOLD,25));
		add(labelaadhar);
		
		JLabel lblaadhar = new JLabel();
		lblaadhar.setBounds(600, 350, 150, 30);
		add(lblaadhar);
		
		JLabel labelempid = new JLabel("Employee Id- ");
		labelempid.setBounds(50, 400, 150, 30);
		labelempid.setFont(new Font("serif",Font.BOLD,25));
		add(labelempid);
		
		lblempid = new JLabel();
		lblempid.setBounds(200, 400, 150, 30);
		lblempid.setFont(new Font("serif",Font.BOLD,25));
		add(lblempid);
		
		try
		{
			Conn c = new Conn();
			String query = "SELECT*FROM employee WHERE empId = '"+empId+"'";
			ResultSet rs = c.s.executeQuery(query);
			while(rs.next())
			{
				lblname.setText(rs.getString("name"));
				tffname.setText(rs.getString("fname"));
				lbldob.setText(rs.getString("dob"));
				tfaddress.setText(rs.getString("address"));
				tfsalary.setText(rs.getString("salary"));
				tfphone.setText(rs.getString("phone"));
				tfemail.setText(rs.getString("email"));
				cbeducation.setToolTipText(rs.getString("education"));
				lblaadhar.setText(rs.getString("aadhar"));
				lblempid.setText(rs.getString("empid"));
				cbdesignation.setToolTipText(rs.getString("designation"));
				//String education = (String) cbeducation.getSelectedItem();
				//String designation1 = (String) cbdesignation.getSelectedItem();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		add = new JButton("Update");
		add.setBounds(250, 550, 150, 40);
		add.setFont(new Font("serif",Font.BOLD,25));
		add.addActionListener(this);
		add.setBackground(Color.BLACK);
		add.setForeground(Color.WHITE);
		add(add);
		
		back = new JButton("Back");
		back.setBounds(450, 550, 150, 40);
		back.setFont(new Font("serif",Font.BOLD,25));
		back.setBackground(Color.BLACK);
		back.setForeground(Color.WHITE);
		back.addActionListener(this);
		add(back);
		
			
		
		setSize(1100,800);
		setLocation(400,100);
		setVisible(true);
		

	}
	
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource() == add)
		{
			String fname = tffname.getText();
			String salary = tfsalary.getText();
			String address = tfaddress.getText();
			String phone = tfphone.getText();
			String email = tfemail.getText();
			String education = (String) cbeducation.getSelectedItem();
			String designation = (String) cbdesignation.getSelectedItem();
			
			try
			{
				Conn conn = new Conn();
				String query = "UPDATE employee SET fname ='"+fname+"',salary ='"+salary+"',address = '"+address+"',phone = '"+phone+"',email = '"+email+"',education ='"+education+"',designation = '"+designation+"' WHERE empid ='"+empId+"'";
				conn.s.executeUpdate(query);
				JOptionPane.showMessageDialog(null, "Details Updated Successfully");
				setVisible(false);
				new Home();
			}
			
			catch (Exception e)
			{
				e.printStackTrace();
			}
			
		}
		else 
		{
			setVisible(false);
			new Home();
		}
	}
	
	
	public static void main(String[] args)
	{
		new UpdateEmployee("");

	}

}
