package employee.management.system;
import javax.swing.*;

public class DeleteEmp extends JFrame
{
	DeleteEmp()
	{
		setSize(1950,1050);
		setLocation(0,0);
		setVisible(true);
	}

	public static void main(String[] args) 
	{
		new DeleteEmp();

	}

}
