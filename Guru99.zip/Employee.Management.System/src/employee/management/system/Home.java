package employee.management.system;

import java.awt.*;

import javax.swing.*;

import java.awt.event.*;

public class Home extends JFrame implements ActionListener
{
	JButton add, view, update, remove, logout;
	
	Home()
	{
		setLayout(null);
		
		ImageIcon i1 = new ImageIcon("C:\\Users\\hari.kishan\\eclipse-workspace\\Employee.Management.System\\src\\icon\\HCLIndia1.jpg");
		Image i2 = i1.getImage().getScaledInstance(1120, 730, Image.SCALE_DEFAULT); 
		ImageIcon i3 = new ImageIcon(i2);
		JLabel image = new JLabel(i3);
		image.setBounds(0, 0, 1120, 630);
		add(image);
		
		JLabel heading = new JLabel("Techies Database");
		heading.setBounds(20,30,600,40);
		heading.setForeground(Color.RED);
		heading.setFont(new Font("algerian", Font.BOLD, 40));
		image.add(heading);
		
		add = new JButton("Add Employees");
		add.setBounds(50, 100, 200, 50);
		add.setFont(new Font("algerian",Font.BOLD,15));
		add.setBackground(Color.YELLOW);
		add.setForeground(Color.BLUE);
		add.addActionListener(this);
		image.add(add);
		
		view = new JButton("View Employees");
		view.setBounds(50, 175, 200, 50);
		view.setFont(new Font("algerian",Font.BOLD,15));
		view.setBackground(Color.YELLOW);
		view.setForeground(Color.BLUE);
		view.addActionListener(this);
		image.add(view);
		
		update = new JButton("Update Employees");
		update.setBounds(50, 250, 200, 50);
		update.setFont(new Font("algerian",Font.BOLD,15));
		update.setBackground(Color.YELLOW);
		update.setForeground(Color.BLUE);
		update.addActionListener(this);
		image.add(update);
		
		remove = new JButton("Remove Employees");
		remove.setBounds(50, 325, 200, 50);
		remove.setFont(new Font("algerian",Font.BOLD,15));
		remove.setBackground(Color.YELLOW);
		remove.setForeground(Color.BLUE);
		remove.addActionListener(this);
		image.add(remove);
		
		logout = new JButton("Logout");
		logout.setBounds(900, 50, 100, 50);
		logout.setFont(new Font("algerian",Font.BOLD,15));
		logout.setBackground(Color.YELLOW);
		logout.setForeground(Color.BLUE);
		logout.addActionListener(this);
		image.add(logout);
		
		
		
		setSize(1120,630);
		setLocation(250,100);
		setVisible(true);
		
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource() == add)
		{
			setVisible(false);
			new AddEmployee();
		}
		else if(ae.getSource()== view)
		{
			setVisible(false);
			new ViewEmployee();
		}
		else if(ae.getSource() == update)
		{
			setVisible(false);
			new ViewEmployee();
		}
		else if(ae.getSource() == remove)
		{
			setVisible(false);
			new RemoveEmployee();
		}
		else if(ae.getSource() == logout)
		{
			setVisible(false);
			new Login();
		}
			
	}

	public static void main(String[] args) 
	{
		new Home();

	}

}
